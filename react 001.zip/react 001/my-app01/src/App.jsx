import ToDo from "./ToDo"

function App(){
  return(
    <div>
      <h1>JSX Exercise</h1>
      <ToDo/>
    </div>
  )
}

export default App;