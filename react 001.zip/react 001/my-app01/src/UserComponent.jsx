function Login(){
  return(
    <div>
        <h1>Login User</h1>
    </div>
  )
}
export default Login;

export function Profile(){
  return(
    <div>
        <h1>Profile</h1>
    </div>
  )
}

export function Setting(){
  return(
    <div>
        <h1>Setting</h1>
    </div>
  )
}

export const UserKey = "milan@123";

