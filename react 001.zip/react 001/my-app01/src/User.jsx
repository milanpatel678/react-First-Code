function User(){
  return <h1>User Component MK</h1>
}

export default User;